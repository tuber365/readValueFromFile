
To run program open command prompt and run following commands:

    $ git clone git@github.com:tuber365/readValueFromFile.git    
    $ cd readValueFromFile
    $ node getAndSetValue.js

Expected output:

    valueForTest1Run: 123
    valueForTest2Run: 1234

Kochee vai, you'll need node install in your computer inorder to run this program.    