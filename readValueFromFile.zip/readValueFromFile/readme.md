To run program open command prompt and run following commands:
    
    $ cd readValueFromFile
    $ node getAndSetValue.js

Expected output:

    valueForTest1Run: 123
    valueForTest2Run: 1234
    